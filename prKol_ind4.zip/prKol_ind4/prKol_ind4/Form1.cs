﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prKol_ind4
{
    public partial class Form1 : Form
    {
        public class Song
        {
            public string Id { get; set; }
            public string Title { get; set; }
            public string Artist { get; set; }

            public Song(string id, string title, string artist)
            {
                Id = id;
                Title = title;
                Artist = artist;
            }
        }
        public Form1()
        {
            InitializeComponent();
            dataGridView1.ColumnCount = 3;
            dataGridView1.Columns[0].Name = "Номер диска";
            dataGridView1.Columns[1].Name = "Исполнитель песня";
            dataGridView1.Columns[2].Name = "Название песни";
        }
        private MusicCatalog mc = new MusicCatalog();
        private void UpdateSongsDataGridView()
        {
            List<Song> allSongs = mc.GetAllSongs();
            dataGridView1.DataSource = allSongs;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string id = numericUpDown1.Value.ToString();
            string title = textBox1.Text;
            string artist = textBox2.Text;
            Song newSong = new Song(id, title, artist);
            mc.AddSong(newSong);
            UpdateSongsDataGridView();
        }
    }
}
