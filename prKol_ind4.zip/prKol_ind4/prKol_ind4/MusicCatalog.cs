﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static prKol_ind4.Form1;

namespace prKol_ind4
{
    internal class MusicCatalog
    {
        private Hashtable songs = new Hashtable();

        public void AddSong(Song song)
        {
            songs.Add(song.Id, song);
        }

        public void RemoveSong(string songId)
        {
            songs.Remove(songId);
        }

        public List<Song> SearchByArtist(string artist)
        {
            List<Song> artistSongs = new List<Song>();
            foreach (Song song in songs.Values)
            {
                if (song.Artist.ToLower() == artist.ToLower())
                {
                    artistSongs.Add(song);
                }
            }
            return artistSongs;
        }
        public List<Song> GetAllSongs()
        {
            return songs.Values.Cast<Song>().ToList();
        }
    }
}
